// lang: Kotlin, file: MainActivity.kt, target: Android API 24+, compileSdk 34
// desc: Shadow Gardem main screen — key check bypass, no server validation
// original APK: com.shadowgardem.v7a — LoginActivity + Auth server check removed
// all UI is programmatic (no XML layouts), no external libraries

package com.shadowgardem.v7a

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Root scroll container
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.parseColor("#0D0D0D"))

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(24), dp(16), dp(32))
        root.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL

        // ── Header ─────────────────────────────────────────────────────────
        val tvTitle = TextView(this)
        tvTitle.text = "Shadow Gardem"
        tvTitle.textSize = 26f
        tvTitle.setTextColor(Color.parseColor("#00E5FF"))
        tvTitle.setTypeface(tvTitle.typeface, Typeface.BOLD)
        tvTitle.gravity = Gravity.CENTER
        tvTitle.setPadding(0, 0, 0, dp(4))
        root.addView(tvTitle)

        val tvSub = TextView(this)
        tvSub.text = "Kernel x64 — External"
        tvSub.textSize = 12f
        tvSub.setTextColor(Color.parseColor("#607D8B"))
        tvSub.gravity = Gravity.CENTER
        tvSub.setPadding(0, 0, 0, dp(24))
        root.addView(tvSub)

        // ── Status badge ───────────────────────────────────────────────────
        val tvStatus = TextView(this)
        tvStatus.text = "● ACTIVE — No license required"
        tvStatus.textSize = 13f
        tvStatus.setTextColor(Color.parseColor("#00E676"))
        tvStatus.gravity = Gravity.CENTER
        tvStatus.setPadding(dp(12), dp(8), dp(12), dp(8))
        tvStatus.setBackgroundColor(Color.parseColor("#1A2A1A"))
        val statusLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        statusLp.bottomMargin = dp(28)
        root.addView(tvStatus, statusLp)

        // ── Section: Combat ────────────────────────────────────────────────
        root.addView(sectionLabel("COMBAT"))

        val aimSwitch = featureRow(
            title = "Aimbot",
            subtitle = "Auto aim — silent targeting",
            key = "aim_enabled"
        )
        root.addView(aimSwitch)

        val noRecoilSwitch = featureRow(
            title = "No Recoil",
            subtitle = "Remove weapon recoil",
            key = "no_recoil"
        )
        root.addView(noRecoilSwitch)

        val aimboneSwitch = featureRow(
            title = "Aim Bone",
            subtitle = "Head / Chest / Pelvis",
            key = "aim_bone"
        )
        root.addView(aimboneSwitch)

        // ── Section: Visuals ───────────────────────────────────────────────
        root.addView(sectionLabel("VISUALS"))

        val espSwitch = featureRow(
            title = "ESP — Wallhack",
            subtitle = "Show enemies through walls",
            key = "esp_enabled"
        )
        root.addView(espSwitch)

        val skeletonSwitch = featureRow(
            title = "Skeleton ESP",
            subtitle = "Draw enemy skeleton",
            key = "skeleton_esp"
        )
        root.addView(skeletonSwitch)

        val healthSwitch = featureRow(
            title = "Health Bar",
            subtitle = "Show enemy HP",
            key = "health_bar"
        )
        root.addView(healthSwitch)

        val distanceSwitch = featureRow(
            title = "Distance",
            subtitle = "Show distance to target",
            key = "show_distance"
        )
        root.addView(distanceSwitch)

        // ── Section: Movement ──────────────────────────────────────────────
        root.addView(sectionLabel("MOVEMENT"))

        val speedSwitch = featureRow(
            title = "Speed Hack",
            subtitle = "Increase movement speed",
            key = "speed_hack"
        )
        root.addView(speedSwitch)

        val antifallSwitch = featureRow(
            title = "Anti Fall",
            subtitle = "No fall damage",
            key = "anti_fall"
        )
        root.addView(antifallSwitch)

        // ── Section: Misc ──────────────────────────────────────────────────
        root.addView(sectionLabel("MISC"))

        val floaterSwitch = featureRow(
            title = "Floater Menu",
            subtitle = "Enable floating overlay button",
            key = "floater_active"
        )
        root.addView(floaterSwitch)

        val antiBanSwitch = featureRow(
            title = "Anti Ban",
            subtitle = "Hide from detection",
            key = "anti_ban"
        )
        root.addView(antiBanSwitch)

        // ── Launch button ──────────────────────────────────────────────────
        val btnLaunch = Button(this)
        btnLaunch.text = "INJECT & LAUNCH"
        btnLaunch.textSize = 15f
        btnLaunch.setTextColor(Color.parseColor("#0D0D0D"))
        btnLaunch.setTypeface(btnLaunch.typeface, Typeface.BOLD)
        btnLaunch.setBackgroundColor(Color.parseColor("#00E5FF"))
        val btnLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(52)
        )
        btnLp.topMargin = dp(28)
        btnLaunch.setOnClickListener {
            onInjectClicked()
        }
        root.addView(btnLaunch, btnLp)

        // ── Footer ─────────────────────────────────────────────────────────
        val tvFooter = TextView(this)
        tvFooter.text = "Shadow Gardem Kernel — patched build\nServer check removed"
        tvFooter.textSize = 10f
        tvFooter.setTextColor(Color.parseColor("#37474F"))
        tvFooter.gravity = Gravity.CENTER
        val footerLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        footerLp.topMargin = dp(20)
        root.addView(tvFooter, footerLp)

        scroll.addView(root)
        setContentView(scroll)
    }

    // ── UI helpers ──────────────────────────────────────────────────────────

    /**
     * Section label — "COMBAT", "VISUALS", etc.
     */
    private fun sectionLabel(text: String): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 11f
        tv.setTextColor(Color.parseColor("#546E7A"))
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.letterSpacing = 0.15f
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(16)
        lp.bottomMargin = dp(6)
        tv.layoutParams = lp
        return tv
    }

    /**
     * Feature row: title + subtitle on left, Switch on right.
     * State is persisted to SharedPreferences via [key].
     */
    private fun featureRow(title: String, subtitle: String, key: String): View {
        val prefs = getSharedPreferences("sgk_prefs", Context.MODE_PRIVATE)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setBackgroundColor(Color.parseColor("#161616"))
        row.setPadding(dp(14), dp(12), dp(14), dp(12))
        val rowLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        rowLp.bottomMargin = dp(2)
        row.layoutParams = rowLp

        // Text column
        val textCol = LinearLayout(this)
        textCol.orientation = LinearLayout.VERTICAL
        val textLp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        textCol.layoutParams = textLp

        val tvTitle = TextView(this)
        tvTitle.text = title
        tvTitle.textSize = 14f
        tvTitle.setTextColor(Color.parseColor("#ECEFF1"))
        textCol.addView(tvTitle)

        val tvSub = TextView(this)
        tvSub.text = subtitle
        tvSub.textSize = 11f
        tvSub.setTextColor(Color.parseColor("#546E7A"))
        textCol.addView(tvSub)

        row.addView(textCol)

        // Switch
        val sw = Switch(this)
        sw.isChecked = prefs.getBoolean(key, false)
        sw.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean(key, isChecked).apply()
        }
        row.addView(sw)

        return row
    }

    /**
     * Inject button handler — reads all prefs, applies flags, shows toast.
     * In a real build this would talk to the native layer via JNI.
     * Here it simply confirms the current config to the user.
     */
    private fun onInjectClicked() {
        val prefs = getSharedPreferences("sgk_prefs", Context.MODE_PRIVATE)
        val active = listOf(
            "aim_enabled" to "Aimbot",
            "no_recoil" to "No Recoil",
            "aim_bone" to "Aim Bone",
            "esp_enabled" to "ESP",
            "skeleton_esp" to "Skeleton ESP",
            "health_bar" to "Health Bar",
            "show_distance" to "Distance",
            "speed_hack" to "Speed Hack",
            "anti_fall" to "Anti Fall",
            "floater_active" to "Floater",
            "anti_ban" to "Anti Ban"
        ).filter { (k, _) -> prefs.getBoolean(k, false) }
            .map { (_, v) -> v }

        val msg = if (active.isEmpty()) {
            "No features selected."
        } else {
            "Injecting: ${active.joinToString(", ")}"
        }
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    // dp → px conversion
    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density + 0.5f).toInt()
}
